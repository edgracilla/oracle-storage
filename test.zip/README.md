# mssql-storage
MS SQL Server Storage Plugin for the Reekoh IoT Platform. Integrates a Reekoh instance with a SQL Server Database to store device data.
